package Dao;

import java.util.List;

import bean.DmCategory;
import bean.DmOrderitem;
import bean.DmOrders;
import bean.DmProduct;

public interface DmOrdersMapper {

	List<DmOrders> selectAll();
	DmOrders selectById(int id);

}
