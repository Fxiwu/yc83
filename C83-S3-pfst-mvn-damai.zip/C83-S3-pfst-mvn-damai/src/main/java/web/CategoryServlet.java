package web;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
 

import Dao.CategoryDao;
import Dao.DmCategoryMapper;
import bean.DmCategory;
 
@WebServlet("/category.do")
public class CategoryServlet extends BaseServlet{
	private static final long serialVersionUID = 1L;
	private CategoryDao cdao = new CategoryDao();
	private SqlSession session ;
	 
	//动态块
	{
		try {
	 
		// mybatis 配置文件
		String resource = "mybatis.xml";
		// 读入配置文件
		InputStream inputStream = Resources.getResourceAsStream(resource);
		// 构建会话工厂  ==>  23 设计模式   工厂模式
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		session = sqlSessionFactory.openSession();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
    protected void query(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	 
		DmCategoryMapper mapper=session.getMapper(DmCategoryMapper.class);
 	     List< DmCategory> dcList=mapper.selectAll();
 	  
 	    
	     

   	List<?> list=dcList;
    	
      print(response,list);
     
    }

	 

	 

}
