package Dao;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Assert;
import org.junit.Test;

import bean.DmCategory;
import bean.DmProduct;

public class ZTest {
	// 开启会话
		private SqlSession session ;
		
		 	
			 
			//动态块
			{
				try {
			 
				// mybatis 配置文件
				String resource = "mybatis.xml";
				// 读入配置文件
				InputStream inputStream = Resources.getResourceAsStream(resource);
				// 构建会话工厂  ==>  23 设计模式   工厂模式
				SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
				session = sqlSessionFactory.openSession();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			//增
			 

			@Test
		    public void test1() throws IOException {
				DmProductMapper mapper=session.getMapper(DmProductMapper.class);
				 
				DmProduct dc = new DmProduct();
				dc.setPname("夏季短袖");
				dc.setMarketPrice(775d);
				dc.setShopPrice(128d );
				dc.setCid(1);
				 
		 		mapper.insert(dc);
		    	// 不commit, 会话会在关闭自动回滚
		 		session.commit();
		 		session.close();
 	 		}
	 	 
	 	 
			//删除
		@Test
	 	public  void test2() throws IOException {
 
			DmProductMapper mapper=session.getMapper(DmProductMapper.class);
	 		
			mapper.delete(72);
	     	// 不commit, 会话会在关闭自动回滚
	 		session.commit();
	 		session.close();
	    	 
	 	}

		//改
	 	@Test
	 	public void test3() throws IOException {
	 		DmProductMapper mapper=session.getMapper(DmProductMapper.class);
			DmProduct dp=new DmProduct();
			//只修改一个字段（market_Price)值
			dp.setId(1);
			dp.setMarketPrice(775d);
			mapper.update(dp);
			//从数据库查出该记录，验证结果
			DmProduct dbdp=mapper.selectById(1);
			 Assert.assertEquals((Double)775d,dbdp.getMarketPrice());
			 Assert.assertEquals((Double)228d,dbdp.getShopPrice());
			 Assert.assertEquals("韩版连帽加厚毛衣女外套",dbdp.getPname());
	 	}
	 	
	 	//查
	 	@Test
	 	public void test4() throws IOException {
	 		DmProductMapper mapper=session.getMapper(DmProductMapper.class);
 	 		DmProduct dbdp=mapper.selectById(2);
		   
	 	}
	 	
	  
	     
	  
}
	 
		 
